from flask import Flask, render_template, request, redirect, url_for
import mysql.connector
import plotly.graph_objects as go

app = Flask(__name__)

# Configure MySQL connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="raj@sql0000",
    database="ai_database"
)

@app.route('/')
def index():
    # Display the form for user input
    return render_template('index.html')

@app.route('/search', methods=['POST'])
def search():
    # Get the data from the form input
    search_term = request.form['search_term']
    
    cursor = db.cursor(dictionary=True)
    
    # SQL Query to fetch specific columns based on input
    query = "select `JOB ID`, `Business Title`, `Agency`, `# Of Positions`, `Level`, `Salary Range From`, `Salary Range To` from nyc_jobs WHERE `Business Title` LIKE %s OR `Job Description` LIKE %s "
    cursor.execute(query, (f"%{search_term}%", "%{search_term}%"))
    
    # Fetch all results
    results = cursor.fetchall()
    
    cursor.close()
    
    # Render results.html and pass the results to the template
    return render_template('results.html', results=results, search_term=search_term)

@app.route('/save_row', methods=['POST'])
def save_row():
    # Fetch data from the form
    job_id = request.form['job_id']
    business_title = request.form['business_title']
    agency = request.form['agency']
    positions = request.form['positions']
    level = request.form['level']
    salary_from = request.form['salary_from']
    salary_to = request.form['salary_to']

    # Print values to check if the form data is being received properly
    print(f"Job ID: {job_id}, Title: {business_title}, Agency: {agency}, Positions: {positions}, Level: {level}, Salary From: {salary_from}, Salary To: {salary_to}")
    
    cursor = db.cursor()

    try:
        # SQL query to insert the row into user_prefs table
        cursor = db.cursor()
        query = "INSERT INTO user_prefs (job_id, business_title, agency, openings, level, salary_from, salary_to) values (%s, %s, %s, %s, %s, %s, %s);"
        cursor.execute(query, (job_id, business_title, agency, positions, level, salary_from, salary_to))
        
        db.commit()  # Save changes
        print("Data inserted successfully!")

    except Exception as e:
        print(f"Error occurred: {e}")
    
    cursor.close()
    
    # Redirect back to the search results page
    return redirect(url_for('index'))

@app.route('/user_Prefs')
def usr_prefs():
    cursor = db.cursor(dictionary=True)
    
    # SQL Query to fetch data from both tables
    query = """
    SELECT 
        u.`business_title`, 
        u.agency, 
        j.`Job Description`, 
        j.`Preferred Skills`, 
        j.`Work Location`
    FROM 
        user_prefs u
    INNER JOIN 
        nyc_jobs j 
    ON 
        u.business_title = j.`Business Title`;
    """
    
    cursor.execute(query)
    results = cursor.fetchall()
    cursor.close()
    
    # Render the template and pass the results
    return render_template('user_Prefs.html', results=results)


@app.route('/jobs_page')
def jobs_page():
    cursor = db.cursor(dictionary=True)
    
    # Fetch the total number of jobs
    query_total_jobs = "SELECT COUNT(*) AS total_jobs FROM nyc_jobs;"
    cursor.execute(query_total_jobs)
    total_jobs = cursor.fetchone()['total_jobs']
    
    # Fetch the sum of all positions
    query_total_openings = "SELECT SUM(`# of Positions`) AS total_openings FROM nyc_jobs;"
    cursor.execute(query_total_openings)
    total_openings = cursor.fetchone()['total_openings']
    
    # Fetch the minimum Salary expectations
    query_min_sal = "SELECT AVG(`Salary Range From`) AS minimum_sal FROM nyc_jobs;"
    cursor.execute(query_min_sal)
    min_salary = cursor.fetchone()['minimum_sal']

    # Fetch the Maximum Salary expectations
    query_max_sal = "SELECT AVG(`Salary Range To`) AS maximum_sal FROM nyc_jobs;"
    cursor.execute(query_max_sal)
    max_salary = cursor.fetchone()['maximum_sal']


    #Fetching Data for the iframe
    #  # Fetch salary data for the boxplot
    # query_salaries = "SELECT `Salary Range From`, `Salary Range To` FROM nyc_jobs"
    # cursor.execute(query_salaries)
    # salary_data = cursor.fetchall()
    
    # # Extract the two columns into separate lists
    # salary_range_from = [row['Salary Range From'] for row in salary_data]
    # salary_range_to = [row['Salary Range To'] for row in salary_data]
    
    # cursor.close()

    # # Create the boxplot using Plotly
    # fig = go.Figure()
    # fig.add_trace(go.Box(y=salary_range_from, name="Salary Range From"))
    # fig.add_trace(go.Box(y=salary_range_to, name="Salary Range To"))
    
    # # Save the plot as an HTML file
    # fig.write_html("templates/boxplot.html") 

    #Recommending Jobs
    # Fetch the business title from user_prefs to find job recommendations
    query_user_prefs = "SELECT business_title FROM user_prefs"
    cursor.execute(query_user_prefs)
    user_prefs = cursor.fetchall()
    
    # Initialize a list to hold all job recommendations
    job_recommendations = []
    
    # For each business title in user preferences, fetch jobs with matching titles
    for user_pref in user_prefs:
        user_business_title = user_pref['business_title']
        
        # Query the nyc_jobs table for similar business titles using LIKE
        query_recommendations = """
            SELECT `Business Title`, `Agency`, `Salary Range From`, `Salary Range To`, `# of Positions`
            FROM nyc_jobs
            WHERE `Business Title` LIKE %s OR `Job Description` LIKE %s
            LIMIT 5
        """


        cursor.execute(query_recommendations, (f"%{user_business_title}%", f"%{user_business_title}%"))
        recommendations = cursor.fetchall()
        
        # Add each set of recommendations to the job_recommendations list
        job_recommendations.extend(recommendations[:5])

        if len(job_recommendations) >= 5:
            break
     
    more_jobs = """
            SELECT `Business Title`, `Agency`, `Salary Range From`, `Salary Range To`, `# of Positions`, `Job Description` FROM nyc_jobs LIMIT 10
        """
    cursor.execute(more_jobs)
    JOBS = cursor.fetchall()
    cursor.close()
    return render_template('Jobs.html', total_jobs=total_jobs, total_openings=total_openings, Min_salary=min_salary, Max_salary=max_salary, job_recommendations=job_recommendations, JOBS=JOBS)

if __name__ == '__main__':
    app.run(debug=True)
